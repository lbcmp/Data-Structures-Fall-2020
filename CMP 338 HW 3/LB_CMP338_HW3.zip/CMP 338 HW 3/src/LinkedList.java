/**
 * You will write the LinkedList.java class which will implement the List Interface. The interface may be downloaded from ListInterface.java.\
 * Please note that you do not inherit from the TestTimes class. 
 */

public class LinkedList<I extends Comparable<? super I>> implements ListInterface<I> {
	private int size = 0;
	private LinkedListNode<I> head = null;
	private LinkedListNode<I> tail = null;

	@Override
	public int size() {
		/**
		 * This method is called to obtain the count of elements in the list.
		 * 
		 * @return 	Returns the numbers of Elements that are currently in the list.
		 */
		
		return this.size;
	}
	
	@Override
	public boolean isEmpty() {
		/**
		 * This method is called to determine if the list is empty.
		 * 
		 * @return 	Returns true if the list is empty, otherwise it returns false. 
		 */
		
		return (size == 0);
	}

	@Override
	public void add(I element) {
		/**
		 * This method is called to add the specified Element to the end of the list.
		 * 
		 * @param 	element	A reference to the element to be added to the end of the list.
		 * 					All Elements being added to the list must implement the 
		 * 					Comparable interface.
		 * 
		 * @see		java.lang.Comparable
		 */
		
		LinkedListNode<I> LinkedListNode = new LinkedListNode<I>(element);
		if (this.size == 0) {
			this.head = LinkedListNode;
			this.tail = LinkedListNode;
		} else {
			this.tail.setNext(LinkedListNode);
			this.tail = LinkedListNode;
		}
		
		size++;
	}
	
	@Override
	public boolean add(I element, int index) {
		/**
		 * This method is called to add the specified Element to the list at the given index.
		 * 
		 * @param 	element	A reference to the element to be added to the list. 
		 * 					All Elements being added to the list must implement the 
		 * 					Comparable interface.
		 * 
		 * @param 	index 	Indicates the position at which to add the specified Element.
		 * 					Using and index = 0, indicates that the Element being added should
		 * 					become the head of the list and should succeed even if
		 * 					the list is currently empty.
		 * 
		 * @return 	Returns true if the Element was successfully added at the given index.
		 * 			If the given index is invalid, this method returns false, indicating
		 * 			that the specified Element was not added to the list.
		 * 
		 * @see		java.lang.Comparable
		 */
		
		if (index <= this.size) {
			if (index == this.size) {
				this.add(element);
			} else if (index == 0) {
				LinkedListNode<I> LinkedListNode = new LinkedListNode<I>(element);
				LinkedListNode.setNext(this.head);
				this.head = LinkedListNode;
				this.size++;
			} else {
				LinkedListNode<I> LinkedListNode = new LinkedListNode<I>(element);
				LinkedListNode<I> previous = this.head;
				index--;
				while (index != 0) {
					previous = previous.getNext();
					index--;
				}
				LinkedListNode.setNext(previous.getNext());
				previous.setNext(LinkedListNode);
				this.size++;
			}
			return true;
		} else {
			return false;
		}
	}
	
	@Override
	public void addSorted(I element) {
		/**
		 * This method is called to add the specified Element to the list in sorted order. More
		 * specifically, the Elements preceding the specified Element must be "less than" the
		 * specified Element, and the Elements following the specified Element must be "greater
		 * that or equal to" the specified Element.
		 * 
		 * @param 	element 	A reference to the element being added, in sorted order, 
		 * 					to the list. All Elements being added to the list must implement the 
		 * 					Comparable interface.
		 * 
		 * @see		java.lang.Comparable
		 */
		
		if (this.isEmpty()) {
			this.add(element);
			return;
		}
		
		LinkedListNode<I> LinkedListNode = new LinkedListNode<I>(element);
		I headElement = head.getData();
		I tailElement = tail.getData();
		
		if (headElement.compareTo(element) >= 0) {
			// inserting before the head
			LinkedListNode.setNext(this.head);
			this.head = LinkedListNode;
		} else if (tailElement.compareTo(element) <= 0) {
			tail.setNext(LinkedListNode);
			this.tail = LinkedListNode;
		} else {
			LinkedListNode<I> prev = head;
			LinkedListNode<I>	next = head.getNext();
			while ((prev != null) && (next != null)) {
				I prevData = prev.getData();
				I nextData = next.getData();
				if ((prevData.compareTo(element) <= 0) && (nextData.compareTo(element) > 0)) {
					break;
				} else {
					prev = next;
					next = prev.getNext();
				}
			}
			LinkedListNode.setNext(next);
			prev.setNext(LinkedListNode);
		}
		this.size++;

	}
	
	@Override
	public I get(int index) {
		/**
		 * This method is called to retrieve the Element at the specified index.
		 * 
		 * @param 	index	Indicates the position from which to retrieve the Element.
		 * 
		 * @return	Returns a reference to the Element at the given index, or nullL
		 * 			if the given index is invalid.
		 */
		
		LinkedListNode<I> LinkedListNode = head;
		while (index != 0) {
			LinkedListNode = LinkedListNode.getNext();
			index--;
		}
		return LinkedListNode.getData();
	}
		
	@Override
	public I replace(I element, int index) {
		/**
		 * 
		 * This method is called to replace the element at the specified index with the specified
		 * obj. The method then returns the replaced element or null if no element exists
		 * at the specified index.
		 * 
		 * @param element	A reference to the element that will replace the current element in the list.
		 * 
		 * @param index Indicates the position in the list where the replacement should be made.
		 * 
		 * @return		If the replacement is successful, the method will return a reference to the replaced
		 * 				element. Otherwise, the method will return null.
		 */
		
		I data = null;
		if (index == 0 ) {
			data = head.getData();
			head.setData(element);
			return data;
		} else if (index == this.size - 1) {
			data = tail.getData();
			tail.setData(element);
			return data;
		} else if (index < this.size) {
			LinkedListNode<I> LinkedListNode = head;
			while (index != 0) {
				LinkedListNode = LinkedListNode.getNext();
				index--;
			}
			data = LinkedListNode.getData();
			LinkedListNode.setData(element);
			return data;
		} else {
			return null;
		}
	}

	@Override
	public boolean remove(int index) {
		/**
		 * This method is called to remove the Element at the specified index
		 * 
		 * @param 	index	Indicates the position from which to remove the Element.
		 * 
		 * @return	Returns true if the Element was successfully removed from the given index, 
		 * 			or false if the given index is invalid.
		 */
		
		if (index > this.size - 1) {
			return false;
		} else if (index == 0) {
			// removing head
			this.head = this.head.getNext();
		} else {
			// removing a middle LinkedListNode
			LinkedListNode<I> previous = this.head;
			index--;
			while (index != 0) {
				previous = previous.getNext();
				index--;
			}
			LinkedListNode<I> LinkedListNodeToRemove = previous.getNext();
			previous.setNext(LinkedListNodeToRemove.getNext());
			if (LinkedListNodeToRemove == tail) {
				this.tail = previous;
			}
		}

		size--;
		return true;
	}
	
	@Override
	public void removeAll() {
		/**
		 * This method removes all Elements from the list, making the list empty.
		 */
		
		this.head = null;
		this.tail = null;
		this.size = 0;
	}
}
