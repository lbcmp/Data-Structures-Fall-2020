/**
 *  You will write the Driver.java class which will implement the Driver Interface. The interface may be downloaded from DriverInterface.java.
 *  Please note that you do not inherit from the TestTimes class. However, you do have to use the TestTimes class to measure test times. 
 */
public class Driver implements DriverInterface {
		
		/**
		 * 
		 * This enum is used to specify which list implementation to use. All list implementations 
		 * used in this assignment will be lists of Integer:
		 * 
		 * The ListType enum has the following choices:
		 * 							
		 * 		ArrayBasedList
		 * 		LinkedList
		 * 							
		 *
		 */
		public static enum ListType {ArrayBasedList, LinkedList};

		/**
		 * 
		 * This enum is used to specify which test scenario will be executed.
		 * 
		 * The TestType enum has the following choices:
		 * 							
		 * 		AddSortedOdd
		 * 		AddSortedEven
		 * 		AddAll
		 * 		AddAllAtIndexZero
		 * 		RemoveAllEven
	 	 * 		RemoveAllOdd
		 * 						
		 *
		 */
		public static enum TestType {AddSortedOdd, AddSortedEven, AddAll, AddAllAtIndexZero, RemoveAllEven, RemoveAllOdd};
	 
		public ListInterface<Integer> createList(ListType listType, TestType forTestType) {
			/**
			 * 
			 * This method is used to create a new list of the specified listType. Depending on the 
			 * specified testType, this method may need to initialize the list with some entries. For example, for the 
			 * AddSortedOdd test case, the list will need to be initialized to contain all the even numbers from 2 to 10,000.
			 * In that case, this method will initialize the list to contain the even numbers after creating the list. 
			 * 
			 * See {@link #initializeList(ListInterface, int, int, int)}
			 * 
			 * @param listType		This parameter specifies the type of list to create. See the enum {@link ListType}.
			 * 
			 * @param forTestType 	This parameter specifies the type of test that the list is being created for. See the enum
			 * {@link TestType}. 
			 * 
			 * @return	The method will return the created list as a ListInterface.
			 * 
			 */
			
			ListInterface<Integer> list;
			
			switch (listType) {
			case LinkedList:
				list = new LinkedList<Integer>();
				break;
			case ArrayBasedList:
				list = new ArrayBasedList<Integer>();
				break;
			default:
				list = null;
				break;
			}
			
			switch(forTestType) {
			case AddSortedEven:
				list = initializeList(list, 1, 9999, 2);
				
				break;
				
			case RemoveAllEven:
				list = initializeList(list, 1, 10000, 1);
				
				break;
				
			case RemoveAllOdd:
				list = initializeList(list, 1, 10000, 1);
				
				break;
			}
			
			return list;
		}
		
		public ListInterface<Integer> initializeList(ListInterface<Integer> list,  int firstNumber, int lastNumber, int increment) {
			/**
			 * 
			 * This method is called by the createList() method to initialize the test list. The test list could either
			 * be an ArrayList or a LinkedList. In either case, it will implement the ListInterface. 
			 * 
			 * @param 	list		The list to be initialized.
			 * @param 	firstNumber	The first number to be added to the list.
			 * @param 	lastNumber	The last number to be added to the list
			 * @param 	increment	The increment to be used by the for loop for each iteration. If the increment is zero, the
			 * 						test list is left empty.
			 * 
			 * @return	The initialized list.
			 * 
			 */
			if (increment != 0) {
				for (int i = firstNumber; i <= lastNumber; i += increment) {
					list.add(i);
				}
			} else {
				list.removeAll();
			}
			
			return list;
		}

		public double memoryUsage() {
			/**
			 * 
			 * This method is used to calculate the amount of memory being used in the JVM currently.
			 * 
			 * @return	a double representing the amount of memory in megabytes currently allocated in
			 * 			the JVM. Please note that you must convert from kilobytes to megabytes.
			 */
	
			double memoryInUse = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
			
			return (memoryInUse / 1000);
		}

		public TestTimes runTestCase(ListType listType, TestType testType, int numberOfTimes) {
			/**
			 * 
			 * This method is called to run a particular test case on a list type up to a total of ten times. The test time
			 * for each run is saved in the TestTimes class.
			 * 
			 * @param 	listType		The type of list needed. See the enum {@link ListType}.
			 * @param 	testType		The type of test case being run. See the enum {@link TestType}.
			 * @param 	numberOfTimes 	This parameter specifies the number of times to run the specified test.
			 * 
			 * @return	An instance of a TestTimes class.
			 * 
			 */
			
			/**
			 *  All the elements being added and removed from the lists must be instances of the Integer class.
			 *  You will test the following scenarios for both the Array Based List and the Linked List implementations:
			 *  
			 *  1. Driver.TestType.AddSortedOdd: Starting with an empty list, use the addSorted(I element) method to add java.lang.Integer objects
			 *  representing the odd numbers (1 ≤ n ≤ 9,999) to the list.
			 *  
			 *  2. Driver.TestType.AddSortedEven: Starting with a list containing the odd numbers less than 10,000, use the addSorted(I element) method
			 *  to add java.lang.Integer objects representing the even numbers (2 ≤ n ≤ 10,000) to the list.
			 *   
			 *  3. Driver.TestType.AddAll: Starting with an empty list, use the add(I element) method to add 10,000 java.lang.Integer objects to the list.
			 *  
			 *  4. Driver.TestType.AddAllAtIndexZero: Starting with an empty list, use the add(I element, int index) method to add 10,000 java.lang.Integer
			 *  objects to the list, all at index = 0.
			 *  
			 *  5. Driver.TestType.RemoveAllEven: Starting with a complete list containing 10,000 java.lang.Integer objects representing all the 
			 *  numbers (1 ≤ n ≤ 10,000); remove all the even numbers by repeatedly calling the remove(int index) method. Remove the even numbers 
			 *  starting with 2, then 4, then 6, ....
			 *  
			 *  6. Driver.TestType.RemoveAllOdd: Starting with a complete list containing 10,000 java.lang.Integer objects representing all the
			 *  numbers (1 ≤ n ≤ 10,000); remove all the odd numbers by repeatedly calling the remove(int index) method. Remove the odd numbers
			 *  starting with 9,999, then 9,997, then 9,995, ....
			 */
			
			TestTimes testTimeTracker = new TestTimes();
			long startTime;
			long endTime;
			long testTime;
	        
			while (numberOfTimes > 0)  {
				startTime = System.nanoTime();
				
				ListInterface<Integer> list = createList(listType, testType);
				
				int numTimes;
				
				switch(testType) {
				case AddSortedOdd:
					for (int i = 1; i < 10000; i += 2) {
						list.add(i);
					}
					
					break;
					
				case AddSortedEven:
					for (int i = 2; i <= 10000; i += 2) {
						list.add(i);
					}
					
					break;
					
				case AddAll:
					numTimes = 10000;
					
					while (numTimes > 0) {
						list.add(7);
						--numTimes;
					}
					
					break;
					
				case AddAllAtIndexZero:
					numTimes = 10000;
					
					while (numTimes > 0) {
						list.add(7, 0);
						--numTimes;
					}
					
					break;
					
				case RemoveAllEven:
					for (int i = 2; i <= 10000; i += 2) {
						list.remove(i);
					}
					
					break;
					
				case RemoveAllOdd:
					for (int i = 9999; i >= 1; i -= 2) {
						list.remove(i);
					}
					
					break;
				}
				
				endTime = System.nanoTime(); 
		        testTime = endTime - startTime;
				testTimeTracker.addTestTime(testTime);
				
				--numberOfTimes;
			}
			
			return testTimeTracker;
		}
		
		public static void print(ListType listType, TestType testType, TestTimes testTimesTracker, double memoryUsage) {
			long[] testTimes = testTimesTracker.getTestTimes();
			
			System.out.print("Running test = " + testType.toString() + "\n\t");
			for (int i = 0; i < testTimes.length; ++i) {
				System.out.print("  Run " + (i + 1) + "  ");
			}
			System.out.print("Average   MemoryUsage \n\t");
			for (int i = 0; i < testTimes.length; ++i) {
				System.out.print(testTimes[i] + "   ");
			}
			System.out.println(testTimesTracker.getAverageTestTime() + "   " + memoryUsage);
			System.out.println("		------- -------	------- -------	------- -------	------- -------	------- -------	------- -----------");
			System.out.println(listType.toString() + "\n");
			
		}
		
		public static void main(String[] args) {
			/**
			 *  Please note that, in addition to implementing the DriverInterface, you are also required to write your own 
			 *  public static main(String[] args) method in Driver.java.
			 *  
			 *  Your main() method will have to call the runTestCase() method for each of test cases listed above a total of ten times for each test case:
			 *  
			 *  For each call to the runTestCase() method your main() method will print out a table with the following output for the Array Based List and
			 *  the Linked List implementations:
			 *   
			 *  Running test = Test Case Name
			 *  		  Run 1   Run 2   Run 3   Run 4   Run 5   Run 6   Run 7   Run 8   Run 9  Run 10 Average Memory Usage
			 *  		Seconds Seconds Seconds Seconds Seconds Seconds Seconds Seconds Seconds Seconds Seconds   Mega Bytes
			 *  		------- -------	------- -------	------- -------	------- -------	------- -------	------- -----------
			 *  ArrayBasedList
			 *  LinkedList
			 *  
			 *  Please note that the test times and the average are in Seconds and the memory usage is in Mega Bytes. You will need to make the necessary conversions. 
			 */
			
			Driver driver = new Driver();
			
			for (TestType testType : TestType.values()) {
				for (ListType listType : ListType.values()) {
					TestTimes testTimesTracker = driver.runTestCase(listType, testType, 10);
					double memoryUsage = driver.memoryUsage();
					print(listType, testType, testTimesTracker, memoryUsage);
				}
			}
		}

		public ListInterface<Integer> createList(DriverInterface.ListType listType, DriverInterface.TestType forTestType) { return null;}

		public TestTimes runTestCase(DriverInterface.ListType listType, DriverInterface.TestType testType, int numberOfTimes) { return null;}	
}
