/**
 *  Your will write the LinkedListNode. Please see the Linked List Node Documentation for all the methods you will need.
 *  Please note that you do not inherit from the TestTimes class. 
 */

public class LinkedListNode<I> {
	
	private I data;
	private LinkedListNode<I> next;
	
	public LinkedListNode() {
		this.data = null;
		this.next = null;
	}
	
	public LinkedListNode(I data) {
		this.data = data;
		this.next = null;
	}

	public I getData() {
		/** Getter method to obtain a reference to the Object held by the LinkedListNode.
		 * 
		 * @return	The Object held by the Node.
		 */
		
		return data;
	}

	public LinkedListNode<I> getNext() {
		/** Getter method to obtain a reference to the next LinkedListNode in the Linked List.
		 * 
		 * @return The next LinkedListNode in the Linked List.
		 */
		
		return next;
	}

	public void setData(I data) {
		/** Setter method to set the reference to the Object held by the LinkedListNode.
		 * 
		 * @param	data - The reference to the Object to be held by the LinkedListNode.
		 */
		
		this.data = data;
	}

	public void setNext(LinkedListNode<I> next) {
		/** Setter method to set the reference to the next LinkedListNode in the Linked List.
		 * 
		 * @param next - The reference to the next LinkedListNode in the Linked List.
		 */
		
		this.next = next;
	}
}
